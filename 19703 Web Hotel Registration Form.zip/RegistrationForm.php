<?php
	$conn = mysqli_connect('localhost', 'root', '', 'myhotel');
	if (!$conn) {
		die("Error: " . mysql_connect_error());
	}
	else{
		echo "Connected Successfully...<br>";
	}
	$customer_name = $_POST['name'];
	$address = $_POST['address'];
	$email = $_POST['email'];
	$nic = $_POST['nic'];
	$mobile = $_POST['mobile'];
	$no_of_rooms = $_POST['nor'];
	$type_of_rooms = $_POST['tor'];
	$preference = $_POST['preference'];
	$package = $_POST['package'];
	$meals = $_POST['meals'];
	$pool = $_POST['pool'];
	$tv = $_POST['tv'];
	$ac = $_POST['ac'];
	$comments = $_POST['comments'];

	$sql = "INSERT INTO registration(customer_name, address, email, nic, mobile, no_of_rooms, type_of_rooms, preference, package, meals, pool, tv, ac, comments) VALUES ('$customer_name', '$address', '$email', '$nic', '$mobile', '$no_of_rooms', '$type_of_rooms', '$preference', '$package', '$meals', '$pool', '$tv', '$ac', '$comments');";
	if (mysqli_query($conn, $sql)) {
		echo "Registered Successfully...";
	}
	else{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
?>