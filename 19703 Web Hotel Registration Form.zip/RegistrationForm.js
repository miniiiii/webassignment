function formValidation()
{
	var name = document.form.name.value.length;
	var address = document.form.address.value.length;
	var email = document.form.email.value;
	var emailLength = document.form.email.value.length;
	const emailFormat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	let preference = false;
	var preferenceValue = document.form.preference.length;
	var mobile = document.form.mobile.value;
	var mobileFormat = /^(?:0|94|\+94|0094)?(?:(11|21|23|24|25|26|27|31|32|33|34|35|36|37|38|41|45|47|51|52|54|55|57|63|65|66|67|81|91)(0|2|3|4|5|7|9)|7(0|1|2|5|6|7|8)\d)\d{6}$/;
	var nicLength = document.form.nic.value.length;
	var nic = document.form.nic.value;
	const nicFormat = /^(([0-9]{9}[x|X|v|V])|([0-9]{12}))$/;
	var NoR = document.form.nor.selectedIndex;
	var ToR = document.form.tor.selectedIndex;
	var package = document.form.package.selectedIndex;
	if (name < 1) 
	{
		alert("Please enter your name...!!!");
	}
	if (address < 1) 
	{
		alert("Please enter your address...!!!");
	}
	if (emailLength < 1) 
	{
		alert("Please enter your email...!!!");
	}
	else if(!email.match(emailFormat))
	{
		alert("Please enter a valid email...!!!");
	}
	if (nicLength < 1) 
	{
		alert("Please enter your NIC Number...!!!");
	}
	else if (!nic.match(nicFormat))
	{
		alert("Please enter a valid NIC Number...!!!");
	}
	if (mobile == "")
	{
		alert("Please enter your mobile number...!!!");
	}
	else if (!mobile.match(mobileFormat)) 
	{
		alert("Please enter a valid mobile number...!!!");
	}
	if (NoR == 0) 
	{
		alert("Please select the number of rooms...!!!");
	}
	if (ToR == 0) 
	{
		alert("Please select the type of rooms...!!!");
	}
	for (var i = 0; i < preferenceValue; i++) {
		if (document.form.preference[i].checked)
		{
			preference = true;
		}
	}
	if (!preference)
	{
		alert("Please select your preferance...!!!");
	}
	if (package == 0) 
	{
		alert("Please select the package...!!!");
	}
}